package com.example.newsapp

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.livedata.observeAsState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController
import coil.compose.AsyncImage
import com.kwabenaberko.newsapilib.models.Article

@Composable
fun HomePage(newsViewModel: NewsViewModel, navController: NavHostController) {
    val articles by newsViewModel.articles.observeAsState(emptyList())
    val isLoading by newsViewModel.isLoading.observeAsState(true)

    Column(modifier = Modifier.fillMaxSize()) {
        CategoriesBar(newsViewModel)

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(12.dp)
        ) {
            if (isLoading) {
                items(6) { // Show shimmer placeholders
                    ShimmerArticleItem()
                }
            } else {
                items(articles) { article ->
                    ArticleItem(article = article, navController)
                }
            }
        }
    }
}

@Composable
fun ArticleItem(article: Article, navController: NavHostController) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp)
            .shadow(4.dp, shape = MaterialTheme.shapes.large),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        shape = MaterialTheme.shapes.large,
        onClick = {
            navController.navigate(NewsArticlePageScreen(article.url))
        }
    ) {
        Column {
            // Image with overlay tag
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(180.dp)
            ) {
                AsyncImage(
                    model = article.urlToImage ?: "https://picsum.photos/500/300",
                    contentDescription = "Article Image",
                    modifier = Modifier
                        .fillMaxSize()
                        .clip(MaterialTheme.shapes.large),
                    contentScale = ContentScale.Crop
                )

                // Category/source overlay
                article.source?.name?.let { sourceName ->
                    Text(
                        text = sourceName,
                        color = Color.White,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier
                            .align(Alignment.BottomStart)
                            .padding(8.dp)
                            .background(
                                Color(0x99000000),
                                shape = CircleShape
                            )
                            .padding(horizontal = 10.dp, vertical = 4.dp)
                    )
                }
            }

            Column(
                modifier = Modifier
                    .padding(12.dp)
            ) {
                Text(
                    text = article.title,
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp,
                    maxLines = 2
                )
                Spacer(modifier = Modifier.height(6.dp))

                Text(
                    text = article.description ?: "",
                    fontSize = 14.sp,
                    color = Color.Gray,
                    maxLines = 2
                )

                Spacer(modifier = Modifier.height(8.dp))

                // Publish time
                article.publishedAt?.let {
                    Text(
                        text = "🕒 ${formatTimeAgo(it)}",
                        fontSize = 12.sp,
                        color = Color.DarkGray
                    )
                }
            }
        }
    }
}

fun formatTimeAgo(publishedAt: String): String {
    return publishedAt.substringBefore("T") // Simple date extraction
}

@Composable
fun CategoriesBar(newsViewModel: NewsViewModel) {
    var searchQuery by remember { mutableStateOf("") }
    var isSearchExpanded by remember { mutableStateOf(false) }
    var selectedCategory by remember { mutableStateOf("General") }

    val categoriesList = listOf(
        "General", "Business", "Entertainment", "Health", "Science", "Sports", "Technology"
    )

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(8.dp)
            .horizontalScroll(rememberScrollState()),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (isSearchExpanded) {
            OutlinedTextField(
                modifier = Modifier
                    .padding(8.dp)
                    .height(48.dp)
                    .border(1.dp, Color.Gray, CircleShape)
                    .clip(CircleShape),
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = { Text("Search latest news...") },
                trailingIcon = {
                    IconButton(
                        onClick = {
                            isSearchExpanded = false
                            if (searchQuery.isNotEmpty()) {
                                newsViewModel.fetchEverythingQuery(searchQuery)
                            }
                        }
                    ) {
                        Icon(
                            imageVector = Icons.Default.Search,
                            contentDescription = "Search Icon"
                        )
                    }
                }
            )
        } else {
            IconButton(onClick = { isSearchExpanded = true }) {
                Icon(
                    imageVector = Icons.Default.Search,
                    contentDescription = "Search Icon"
                )
            }
        }

        categoriesList.forEach { category ->
            AssistChip(
                onClick = {
                    selectedCategory = category
                    newsViewModel.fetchTopHeadlines(category)
                },
                label = { Text(text = category, fontSize = 14.sp) },
                modifier = Modifier
                    .padding(horizontal = 6.dp),
                colors = AssistChipDefaults.assistChipColors(
                    containerColor = if (category == selectedCategory) Color(0xFFFF4B2B) else Color(0xFFffedea),
                    labelColor = if (category == selectedCategory) Color.White else Color(0xFF0A0301)
                ),
                leadingIcon = if (category == selectedCategory) {
                    { Icon(Icons.Default.Check, contentDescription = null, tint = Color.White) }
                } else null
            )
        }
    }
}
