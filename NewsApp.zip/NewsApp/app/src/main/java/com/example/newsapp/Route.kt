package com.example.newsapp

import kotlinx.serialization.Serializable


@Serializable
object HomePageScreen

@Serializable
data class NewsArticlePageScreen(
    val url : String
)