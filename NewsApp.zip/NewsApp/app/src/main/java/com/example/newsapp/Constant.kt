package com.example.newsapp

object Constant {
    val apiKey = "2b7fa8cb516d4447bf380b44fc53ec91"
}